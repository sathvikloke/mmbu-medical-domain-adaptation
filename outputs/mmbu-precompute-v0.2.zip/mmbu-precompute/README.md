# MMBU preparation package

A CPU-only foundation for the Medical Domain Adaptation entry. It validates provenance and split lineage, isolates task/context/judge inputs, checks output formats and geometry, and computes the published adaptation formula from **already supplied correctness grades**. It is not an official evaluator, semantic judge, training pipeline, or evidence of model quality.

Einstein GPU access is reported but unreliable; IT follow-up is pending. No model weights, biomedical examples, CUDA stack, or paid services are required for this package. The five shipped shape images are synthetic engineering fixtures, not biomedical training data. The twenty grade rows are hand-constructed arithmetic examples, not model predictions.

## Run locally

From this directory with Python 3.11 or newer:

```sh
PYTHONPATH=src python3 -m unittest discover -s tests -v
PYTHONPATH=src python3 -m mmbu_prep status
PYTHONPATH=src python3 -m mmbu_prep demo
PYTHONPATH=src python3 -m mmbu_prep validate examples/engineering-manifest.jsonl --image-root examples --purpose engineering
PYTHONPATH=src python3 -m mmbu_prep score examples/pregraded-toy.jsonl --bootstrap 1000 --seed 17
```

These commands work offline. Invalid input returns a nonzero exit status. Core runtime dependencies are Python's standard library; source execution above needs no installation. Optional editable installation uses setuptools and is unnecessary for these checks. Run from this directory, or pass `--workspace /path/to/mmbu-precompute` before the subcommand for configuration/example lookup.

The complete suite was exercised on Python 3.12.14 and 3.14.7. Python 3.11 syntax was checked; its runtime was not available for execution in this workspace.

## Version 0.2 additions

Joint paired candidate comparison, optional Pillow image inspection, and a BBBC039 source-training quarantine converter are now implemented. The separate local intake inspected 100 real microscopy fields and produced 198 **unapproved** candidate records; no source has been cleared for model use. See `docs/bbbc039-intake.md`, `docs/image-inspection.md`, and `docs/candidate-comparison.md`. Real raw archives/images remain outside this portable bundle.

Image functions require the optional `images` dependency (Pillow 12.3 series; verified with 12.3.0). Core commands remain standard-library only. Tests requiring Pillow explicitly skip when it is absent.

```sh
PYTHONPATH=src python3 -m mmbu_prep compare examples/candidate-grades-toy.json --bootstrap 1000 --seed 17
PYTHONPATH=src python3 -m mmbu_prep inspect-images examples/engineering-manifest.jsonl --image-root examples
```

The comparison JSON maps candidate names to grade arrays. Optional `--weights` supplies a JSON object keyed by record ID; the same weights and bootstrap draws are used for every candidate. Intervals remain exploratory and do not select a winner. The image command checks file decoding and exact decoded duplicate groups; it does not establish annotation quality or near-duplicate absence.

## What is implemented

- Fresh, separate task/context/judge input objects and explicitly provisional output parsing. Reference answers and options never enter model input through these builders.
- Strict JSON loading, pixel xywh validation and IoU arithmetic without prediction repair or clamping.
- Source permission/provenance checks, SHA-256 checks, duplicate IDs and connected image/parent/group leakage detection. Deterministic split assignment requires an approved external source registry.
- Per-example context averaging and signed adaptation score. The balanced development proxy requires all four task groups. Cluster resampling preserves paired grades and fixed source mass; it does not establish hidden-set or training-seed uncertainty.
- Source/protocol/model registries, experiment and confirmation records, calibration/review sheets, and an Einstein handoff checklist.

## What remains unresolved

The organizer's final output/grading contract and public-dev permissions remain unresolved. All real biomedical source candidates remain unapproved in the registry until the relevant source and intended conversion are reviewed. Metadata retrieval does not verify model loading, memory fit or public-weight-release compatibility. No native baseline, adaptation run, semantic judge calibration, biomedical label review, or BF16/FP16 model export has been executed.

Read `docs/input-contracts.md`, `docs/data-contract.md`, `docs/statistics.md`, and `docs/source-screening.md` before connecting this to real data. `docs/organizer-questions.md` is a draft, not a sent message. `docs/einstein-handoff.md` specifies the facts needed after IT restores access.

## Data and score inputs

`validate` accepts a JSON array or JSONL records described in `docs/data-contract.md`. File verification is performed when `--image-root` is provided; byte hashes cannot establish image decoding, near-duplicate absence, correct labels or ethical/contractual eligibility. A registry is a human-maintained evidence record, not a license authority.

`score` accepts rows with `record_id`, `source_id`, `group_id`, `task`, `base_correct`, `adapted_correct`, and `context_correct` (a mapping of annotated field names to binary grades). Preserve every evaluation example, including failed predictions once its grade is determined under the confirmed protocol. Zero-context-field examples are rejected because the official policy is unresolved. Any exclusion would change the evaluation population and must be justified separately.

To assign splits after a source is actually approved:

```sh
PYTHONPATH=src python3 -m mmbu_prep split /path/to/approved-records.jsonl \
  --registry /path/to/reviewed-registry.json --image-root /path/to/images \
  --ratios '{"train":0.8,"dev":0.1,"confirmation":0.1}' --seed 20261003 \
  --output /path/to/new-assigned-records.jsonl
```

The ratios are an example, not the finalized study design. Assignment proportions are approximate at the connected-group level. Check the realized source/task/group counts before freezing. The command refuses to overwrite an existing output. Never use a different seed after inspecting confirmation results.

## Evidence

`evidence/` records test runs, primary-source retrievals and review results. Initial failing test logs are historical development evidence, not current failures; the final verification summary identifies the current suite result. `configs/model-registry.json` pins metadata revisions for later checks, without downloading weights. `configs/resources.json` contains explicitly unknown capacity values.


Current release verification is recorded in `evidence/batch2-final-test-runs.json` and the parent `MMBU-precompute-v0.2-verification.json`. Older `final-test-runs.json` and review files preserve the 0.1 history. See `docs/batch2-work-record.md` for the new audit scope and repaired defects, and `docs/model-preflight.md` for actual checkpoint metadata and its memory-estimate limits.
